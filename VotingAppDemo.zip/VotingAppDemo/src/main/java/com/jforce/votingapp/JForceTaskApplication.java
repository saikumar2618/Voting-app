package com.jforce.votingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.jforce.votingapp.dao.registerRepository;
import com.jforce.votingapp.dao.userRepository;


@SpringBootApplication
public class JForceTaskApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(JForceTaskApplication.class, args);
		userRepository userrepository = context.getBean(userRepository.class);
		registerRepository registerrepository = context.getBean(registerRepository.class);
		
		
	}

}
